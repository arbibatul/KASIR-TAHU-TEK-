# Kasir Warung
Aplikasi kasir warung makan berbasis HTML/CSS/JavaScript. Data disimpan lokal di browser melalui localStorage dan dapat dibackup/restore.

## Jalankan cepat
1. Buka `index.html` di browser Android/Chrome.
2. Data contoh otomatis muncul. Ubah/hapus sesuai usaha.
3. Untuk PWA/service worker, host folder ini pada HTTPS (GitHub Pages/Netlify/hosting lain) lalu buka URL-nya di Chrome Android.
4. Di Chrome pilih menu browser > Tambahkan ke layar utama / Install app bila tersedia.

## Fitur
Dashboard, kasir, menu, HPP/porsi, transaksi, cetak struk, pengeluaran (operasional/aset/prive), modal awal, laporan, CSV, backup/restore JSON, PWA.

## Batasan
- Penyimpanan localStorage hanya pada browser/perangkat tersebut; tidak ada sinkronisasi cloud.
- HPP memakai HPP/porsi pada menu. Belum ada modul stok bahan/resep dan perhitungan persediaan FIFO/average.
- CSV dapat dibuka di Excel/Google Sheets, tetapi bukan file XLSX native.
- Untuk usaha jangka panjang, gunakan backup rutin dan pertimbangkan backend/database terautentikasi.
